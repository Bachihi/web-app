

CREATE TABLE IF NOT EXISTS `test22` (
  `id` bigint(20) NOT NULL,
  KEY `fk_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
