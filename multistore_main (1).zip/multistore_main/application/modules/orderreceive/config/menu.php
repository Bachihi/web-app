<?php

// module name
$HmvcMenu["purchase_order"] = array(
    //set icon
    "icon"           => "<i class='fa fa-list'></i>", 

    // purchase_order
 
        'add'    => array( 
            "controller" => "purchase_order",
            "method"     => "form",
            "permission" => "create"
        ), 
  
);
   

 