<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Orderreceive_model extends CI_Model {
 
	
}
